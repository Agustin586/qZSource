/*
 * DelayUs.h
 *
 *  Created on: 31 may. 2023
 *      Author: guido
 */

#ifndef DELAYUS_H_
#define DELAYUS_H_

extern void DelayUs(Uint16);

#endif /* DELAYUS_H_ */
